"""
Strings and Characters

"""
