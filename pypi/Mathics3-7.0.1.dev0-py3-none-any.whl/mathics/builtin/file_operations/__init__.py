"""
File Operations
"""
# Note: everything in this module is not loaded if environment
# variable ENABLE_FILES_MODULE is False.  Here we do not want to
# include any built-in commands that can write to the filesytesm.


# This tells documentation how to sort this module
sort_order = "mathics.builtin.file-operations"
