"""
Testing Expressions


There are a number of functions for testing Expressions.

Functions that "ask a question" have names that end in "Q". \
They return 'True' for an explicit answer, and 'False' otherwise.
"""
