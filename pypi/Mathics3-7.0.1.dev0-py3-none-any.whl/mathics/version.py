# -*- coding: utf-8 -*-


# This file is suitable for sourcing inside POSIX shell as
# well as importing into Python. That's why there is no
# space around "=" below.
# fmt: off
__version__="7.0.1dev0"  # noqa
